﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_WEEK_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dt; DataTable dtteam; DataTable dtaway; DataTable player;
        DataTable type; DataTable dmatch; 
        string query; string idhome; string idaway; string idteam; int index;


        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =root;" + "pwd=Feli0102;" + "database=premier_league");
            dtteam = new DataTable(); dtaway = new DataTable();
            query = "select team_id, team_name from team t";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam); sqlDataAdapter.Fill(dtaway);

            cb_home.DataSource = dtteam;
            cb_home.DisplayMember = "team_name";
            cb_home.ValueMember = "team_id";
            cb_home.SelectedIndex = -1;

            cb_away.DataSource = dtaway;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";
            cb_away.SelectedIndex = -1;

            type = new DataTable();
            type.Columns.Add("ID");
            type.Columns.Add("Name");
            type.Rows.Add("GO", "Goal");
            type.Rows.Add("GP", "Goal Penalty");
            type.Rows.Add("GW", "Own Goal");
            type.Rows.Add("CR", "Red Card");
            type.Rows.Add("CY", "Yellow Card");
            type.Rows.Add("PM", "Penalty Miss");

            cb_type.DataSource = type;
            cb_type.DisplayMember = "Name";
            cb_type.ValueMember = "ID";
            cb_type.SelectedIndex = -1;

            dt = new DataTable();
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("type");
            dmatch.Columns.Add("delete");

        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex != -1 && cb_away.SelectedIndex != -1)
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex != -1 && cb_away.SelectedIndex != -1)
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            if (cb_team.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cb_team.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            query = $"select player_id, player_name from player where team_id like '%{idteam}%'";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
            cb_player.SelectedIndex = -1;
        }

        private void date_ValueChanged(object sender, EventArgs e)
        {
            int tgl = Convert.ToInt32(date.Value.Day);
            int bln = Convert.ToInt32(date.Value.Month);
            int thn = Convert.ToInt32(date.Value.Year);
            bool yn = false;
            if(thn < 2016)
            {
               MessageBox.Show("ERROR");
            }
            if(thn == 2016)
            {
                if(bln < 2)
                {
                    MessageBox.Show("ERROR");
                }
                if(bln == 2)
                {
                    if(tgl >= 15)
                    {
                        yn = true;
                    }
                    else if(tgl <= 14)
                    {
                        MessageBox.Show("ERROR");
                    }
                }
                if(bln > 2)
                {
                    yn = true;
                }
            }
            if(thn > 2016)
            {
                yn = true;
            }
            if(yn)
            {
                DataTable count = new DataTable();
                string year = date.Value.Year.ToString();
                query = $"select count(match_id) from `match` where match_id like '{year}%';";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(count);

                if (Convert.ToInt32(count.Rows[0][0]) < 10)
                {
                    tb_id.Text = $"{year}00{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
                }
                else if (Convert.ToInt32(count.Rows[0][0]) >= 10 && Convert.ToInt32(count.Rows[0][0]) < 100)
                {
                    tb_id.Text = $"{year}0{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
                }
                else if (Convert.ToInt32(count.Rows[0][0]) >= 100)
                {
                    tb_id.Text = $"{year}{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
                }
            }
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            if(tb_minute.Text != "" && cb_team.SelectedIndex != -1 && cb_player.SelectedIndex != -1 && cb_type.SelectedIndex != -1)
            {
                dt.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.SelectedValue);
                dgv.DataSource = dt;
                dmatch.Rows.Add(tb_id.Text, tb_minute.Text, idteam, cb_player.SelectedValue, cb_type.SelectedValue, 0);
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv.DataSource = dt;
            dmatch.Rows.RemoveAt(index);
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            //insert dmatch
            try
            {
                sqlConnect.Open();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    query = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //insert match
            int scorehome = 0; int scoreaway = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
               if (dt.Rows[i][1].ToString() == cb_home.Text)
               {
                    if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                    {
                        scorehome++;
                    }
                    if(dt.Rows[i][3].ToString() == "GW")
                    {
                        scoreaway++;
                    }
               }
               else if (dt.Rows[i][1].ToString() == cb_away.Text)
               {
                    if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                    {
                        scoreaway++;
                    }
                    if (dt.Rows[i][3].ToString() == "GW")
                    {
                        scorehome++;
                    }
                }
            }
            try
            {
                query = $"insert into `match` values ('{tb_id.Text}', '{date.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {scorehome}, {scoreaway}, 'M002', 0);";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void tb_minute_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }
    }
}
